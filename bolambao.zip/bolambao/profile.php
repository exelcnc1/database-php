<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Profile</title>
</head>
<body>
    <header>
        <h1>Profile</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="educational.php">Educational Background</a></li>
                <li><a href="hobbies.php">Hobbies</a></li>
                <li><a href="talents.php">Talents</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>About Me</h2>
        <img src="pabukid.jpg" alt="Profile Image" style="display: block; margin-left: auto; margin-right: auto;">
        <?php
            include("bolambaodb.php");
            
            // Insert data if not already present
            $checkQuery = "SELECT * FROM personal_info LIMIT 1";
            $result = $conn->query($checkQuery);
            
            if ($result->num_rows == 0) {
                $sql = "INSERT INTO personal_info (name, birthdate, address, age, email) 
                        VALUES ('Jithrix Exiel C. Bolambao', '2004-10-15', 'Sibonga, Cebu', 20, 'jithrixexiel2@gmail.com')";
                $conn->query($sql);
            }
            
            // Fetch and display data
            $result = $conn->query($checkQuery);
            if ($result->num_rows > 0) {
                $row = $result->fetch_assoc();
                echo "<p>Hello! My name is " . $row['name'] . ". I am passionate about anything that i like and love. This is a brief overview of my life and experiences.</p>";
                echo "<p>Birthdate: " . date('F d, Y', strtotime($row['birthdate'])) . "</p>";
                echo "<p>Address: " . $row['address'] . "</p>";
                echo "<p>Age: " . $row['age'] . "</p>";
                echo "<p>Email: " . $row['email'] . "</p>";
            }
            $conn->close();
        ?>
    </main>
</body>
</html>