<?php
$conn = mysqli_connect("localhost", "root", "", "bolambaodb");

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($conn) {
    echo "Database connection successful";
} else {
    echo "Database connection failed";
}
?>