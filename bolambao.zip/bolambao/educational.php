<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Educational Background</title>
</head>
<body>
    <header>
        <h1>Educational Background</h1>
        <nav>
            <ul>    
                <li><a href="index.php">Home</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="hobbies.php">Hobbies</a></li>
                <li><a href="talents.php">Talents</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>My Education</h2>
        <img src="pabukid3.png" alt="Education Image" style="display: block; margin-left: auto; margin-right: auto;">
        <p>I am currently enrolled at University of Southern Philippines Foundation with a degree in Bachelor in Science in Information Technology. My educational journey has shaped my career and personal growth. Here are some highlights:</p>
        <?php
            include("bolambaodb.php");
            
            // Insert education data if not already present
            $checkQuery = "SELECT * FROM education";
            $result = $conn->query($checkQuery);
            
            if ($result->num_rows == 0) {
                $education = [
                    ['Elementary', 'Cagay Elementary School', 2016],
                    ['High School', 'Teodoro dela Vega Memorial National High School', 2020],
                    ['Senior High School', 'Teodoro dela Vega Memorial National High School', 2023]
                ];
                
                foreach ($education as $edu) {
                    $sql = "INSERT INTO education (level, school_name, graduation_year) 
                           VALUES ('$edu[0]', '$edu[1]', $edu[2])";
                    $conn->query($sql);
                }
            }
            
            // Fetch and display education
            $result = $conn->query($checkQuery);
            echo "<ul>";
            while ($row = $result->fetch_assoc()) {
                if ($row['level'] == 'College') {
                    echo "<li>" . $row['level'] . ": " . $row['school_name'] . ", currently enrolled" . "</li>";
                } else {
                    echo "<li>" . $row['level'] . ": " . $row['school_name'] . ", graduated in " . $row['graduation_year'] . "</li>";
                }
            }
            echo "</ul>";
            
            $conn->close();
        ?>
    </main>
    <footer>
        <p>&copy; 2023 My Autobiography</p>
    </footer>
</body>
</html>
