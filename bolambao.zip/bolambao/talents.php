<?php
    include("bolambaodb.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Talents</title>
</head>
<body>
    <header>
        <h1>Talents</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="educational.php">Educational Background</a></li>
                <li><a href="hobbies.php">Hobbies</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>My Talents</h2>
        <img src="pabukid2.jpg" alt="Talents Image" style="display: block; margin-left: auto; margin-right: auto;">
        <p>I have developed several talents over the years that I take pride in. Here are some of my key talents:</p>
        <?php
            // Fetch talents and ratings from database
            $sql = "SELECT * FROM talents";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                echo "<ul>";
                while($row = mysqli_fetch_assoc($result)) {
                    echo "<li>" . $row['talent_name'] . " - Rating: " . $row['rating'] . "/10</li>";
                }
                echo "</ul>";
            } else {
                // Fallback if no database entries exist
                echo "<ul>
                    <li>Cooking - Rating: 8/10</li>
                    <li>Field work - Rating: 7/10</li>
                    <li>Swimming - Rating: 6/10</li>
                    <li>Basketball - Rating: 7/10</li>
                    <li>Critical thinking skills - Rating: 8/10</li>
                    <li>Singing - Rating: 7/10</li>
                </ul>";
            }
        ?>
    </main>
    <footer>
        <p>&copy; 2023 My Autobiography</p>
    </footer>
</body>
</html>