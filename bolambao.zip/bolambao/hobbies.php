<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Hobbies</title>
</head>
<body>
    <header>
        <h1>Hobbies</h1>
        <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="educational.php">Educational Background</a></li>
                <li><a href="talents.php">Talents</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>My Hobbies</h2>
        <img src="pabukid1.jpg" alt="Hobbies Image" style="display: block; margin-left: auto; margin-right: auto;">
        <p>In my free time, I enjoy a variety of hobbies that keep me engaged and creative. These are one of my favorite activities:</p>
        <?php
            include("bolambaodb.php");
            
            // Insert hobbies if not already present
            $checkQuery = "SELECT * FROM hobbies";
            $result = $conn->query($checkQuery);
            
            if ($result->num_rows == 0) {
                $hobbies = [
                    'Basketball',
                    'Swimming',
                    'Hiking and exploring nature',
                    'Cooking',
                    'Motorcycles',
                    'Sleeping'
                ];
                
                foreach ($hobbies as $hobby) {
                    $sql = "INSERT INTO hobbies (hobby_name) VALUES ('" . $conn->real_escape_string($hobby) . "')";
                    if (!$conn->query($sql)) {
                        echo "Error inserting hobby: " . $conn->error;
                    }
                }
            }
            
            // Fetch and display hobbies
            $result = $conn->query($checkQuery);
            if ($result) {
                echo "<ul>";
                while ($row = $result->fetch_assoc()) {
                    echo "<li>" . htmlspecialchars($row['hobby_name']) . "</li>";
                }
                echo "</ul>";
            } else {
                echo "Error fetching hobbies: " . $conn->error;
            }
            
            $conn->close();
        ?>
    </main>
    <footer>
        <p>&copy; 2025 Autobiography exiel</p>
    </footer>
</body>
</html>