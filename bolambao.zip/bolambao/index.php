<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>My Autobiography</title>
</head>
<body>
    <header>
        <h1>My Autobiography</h1>
        <nav>
            <ul>
                <li><a href="profile.php">Profile</a></li>
                <li><a href="educational.php">Educational Background</a></li>
                <li><a href="Hobbies.php">Hobbies</a></li>
                <li><a href="talents.php">Talents</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <h2>Welcome to My Autobiography</h2>
        <p>Click on the sections in the menu to learn more about my life.</p>
    </main>
</body>
</html>
<?php
    include("bolambaodb.php");
?>